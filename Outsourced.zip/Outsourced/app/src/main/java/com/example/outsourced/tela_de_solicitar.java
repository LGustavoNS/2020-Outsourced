package com.example.outsourced;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tela_de_solicitar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_de_solicitar);
    }
}
